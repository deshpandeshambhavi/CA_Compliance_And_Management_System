-- ============================================================
--  CA Manager v2 — Add multi-firm support
--  Run this AFTER ca_management.sql
-- ============================================================

USE ca_management;

-- 1. CA Firm table (for signup/login)
CREATE TABLE IF NOT EXISTS CA_Firm (
    Firm_ID    INT AUTO_INCREMENT PRIMARY KEY,
    Firm_Name  VARCHAR(100) NOT NULL,
    Email      VARCHAR(100) NOT NULL UNIQUE,
    Password   VARCHAR(255) NOT NULL,
    Phone      VARCHAR(15),
    Address    VARCHAR(200),
    Created_At DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Add Firm_ID to Client table
ALTER TABLE Client ADD COLUMN IF NOT EXISTS Firm_ID INT;
ALTER TABLE Client ADD CONSTRAINT fk_client_firm
    FOREIGN KEY (Firm_ID) REFERENCES CA_Firm(Firm_ID) ON DELETE CASCADE;

-- 3. Insert a default firm so existing sample data still works
INSERT INTO CA_Firm (Firm_Name, Email, Password, Phone, Address)
VALUES ('Demo CA Firm', 'demo@cafirm.com', 'demo123', '9999999999', 'Mumbai');

-- 4. Assign all existing clients to the demo firm
UPDATE Client SET Firm_ID = 1 WHERE Firm_ID IS NULL;
